"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import {
  DndContext,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core"
import { SortableContext, arrayMove } from "@dnd-kit/sortable"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { getCurrentUser } from "@/lib/auth"
import { db } from "@/lib/db"
import type { Board, Card as CardType, Column as ColumnType, Dependency, User } from "@/lib/db/schema"
import { ArrowLeft, Layout } from "lucide-react"
import Column from "@/components/board/column"
import DependencyVisualizer from "@/components/board/dependency-visualizer"

interface BoardPageProps {
  params: {
    id: string
  }
}

export default function BoardPage({ params }: BoardPageProps) {
  const router = useRouter()
  const boardId = params.id
  const [user, setUser] = useState<User | null>(null)
  const [board, setBoard] = useState<Board | null>(null)
  const [columns, setColumns] = useState<ColumnType[]>([])
  const [cards, setCards] = useState<CardType[]>([])
  const [dependencies, setDependencies] = useState<Dependency[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeCard, setActiveCard] = useState<CardType | null>(null)
  const [isCardDialogOpen, setIsCardDialogOpen] = useState(false)
  const [isDependencyDialogOpen, setIsDependencyDialogOpen] = useState(false)
  const [newCardData, setNewCardData] = useState({
    title: "",
    description: "",
    columnId: "",
  })
  const [newDependencyData, setNewDependencyData] = useState({
    sourceCardId: "",
    targetCardId: "",
  })
  const [editingCard, setEditingCard] = useState<CardType | null>(null)

  const boardRef = useRef<HTMLDivElement>(null)

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
  )

  useEffect(() => {
    async function loadData() {
      try {
        const currentUser = await getCurrentUser()
        setUser(currentUser)

        if (!boardId) return

        const boardData = await db.getBoardById(boardId)
        if (!boardData) {
          router.push("/dashboard")
          return
        }

        setBoard(boardData)

        const columnsData = await db.getColumnsByBoard(boardId)
        setColumns(columnsData)

        const cardsData = await db.getCardsByBoard(boardId)
        setCards(cardsData)

        const dependenciesData = await db.getDependenciesByBoard(boardId)
        setDependencies(dependenciesData)
      } catch (error) {
        console.error("Failed to load board data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [boardId, router])

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event
    const activeCardId = active.id as string
    const foundCard = cards.find((card) => card.id === activeCardId)
    if (foundCard) {
      setActiveCard(foundCard)
    }
  }

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event
    if (!over) return

    const activeCardId = active.id as string
    const overCardId = over.id as string

    // Find the active card
    const activeCard = cards.find((card) => card.id === activeCardId)
    if (!activeCard) return

    // Check if over a column
    const overColumn = columns.find((column) => column.id === overCardId)
    if (overColumn) {
      // If the card is already in this column, do nothing
      if (activeCard.columnId === overColumn.id) return

      // Move the card to the new column
      const updatedCards = cards.map((card) => {
        if (card.id === activeCardId) {
          return { ...card, columnId: overColumn.id }
        }
        return card
      })

      setCards(updatedCards)
      return
    }

    // Check if over another card
    const overCard = cards.find((card) => card.id === overCardId)
    if (!overCard || activeCard.columnId !== overCard.columnId) return

    // Reorder cards within the same column
    const columnCards = cards.filter((card) => card.columnId === activeCard.columnId).sort((a, b) => a.order - b.order)

    const activeIndex = columnCards.findIndex((card) => card.id === activeCardId)
    const overIndex = columnCards.findIndex((card) => card.id === overCardId)

    if (activeIndex === -1 || overIndex === -1) return

    const newOrder = arrayMove(columnCards, activeIndex, overIndex)

    // Update the order of cards
    const updatedCards = cards.map((card) => {
      const newIndex = newOrder.findIndex((c) => c.id === card.id)
      if (newIndex !== -1 && card.columnId === activeCard.columnId) {
        return { ...card, order: newIndex }
      }
      return card
    })

    setCards(updatedCards)
  }

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event
    if (!over || !user) return

    const activeCardId = active.id as string
    const overCardId = over.id as string

    // Find the active card
    const activeCard = cards.find((card) => card.id === activeCardId)
    if (!activeCard) return

    // Check if over a column
    const overColumn = columns.find((column) => column.id === overCardId)
    if (overColumn) {
      // Update the card in the database
      await db.updateCard(activeCardId, {
        columnId: overColumn.id,
        order: cards.filter((card) => card.columnId === overColumn.id).length,
      })
    } else {
      // Update all cards in the column with their new order
      const columnCards = cards
        .filter((card) => card.columnId === activeCard.columnId)
        .sort((a, b) => a.order - b.order)

      for (let i = 0; i < columnCards.length; i++) {
        await db.updateCard(columnCards[i].id, { order: i })
      }
    }

    setActiveCard(null)
  }

  const handleAddCard = (columnId: string) => {
    setNewCardData({
      title: "",
      description: "",
      columnId,
    })
    setEditingCard(null)
    setIsCardDialogOpen(true)
  }

  const handleEditCard = (card: CardType) => {
    setEditingCard(card)
    setNewCardData({
      title: card.title,
      description: card.description || "",
      columnId: card.columnId,
    })
    setIsCardDialogOpen(true)
  }

  const handleSaveCard = async () => {
    if (!user || !board || !newCardData.title.trim() || !newCardData.columnId) return

    try {
      if (editingCard) {
        // Update existing card
        const updatedCard = await db.updateCard(editingCard.id, {
          title: newCardData.title.trim(),
          description: newCardData.description.trim() || undefined,
          columnId: newCardData.columnId,
        })

        if (updatedCard) {
          setCards(cards.map((card) => (card.id === updatedCard.id ? updatedCard : card)))
        }
      } else {
        // Create new card
        const columnCards = cards.filter((card) => card.columnId === newCardData.columnId)
        const newCard = await db.createCard({
          title: newCardData.title.trim(),
          description: newCardData.description.trim() || undefined,
          columnId: newCardData.columnId,
          boardId: board.id,
          createdBy: user.id,
          order: columnCards.length,
        })

        setCards([...cards, newCard])
      }

      setIsCardDialogOpen(false)
      setNewCardData({
        title: "",
        description: "",
        columnId: "",
      })
      setEditingCard(null)
    } catch (error) {
      console.error("Failed to save card:", error)
    }
  }

  const handleDeleteCard = async (cardId: string) => {
    try {
      const success = await db.deleteCard(cardId)
      if (success) {
        setCards(cards.filter((card) => card.id !== cardId))
        setDependencies(dependencies.filter((dep) => dep.sourceCardId !== cardId && dep.targetCardId !== cardId))
      }
    } catch (error) {
      console.error("Failed to delete card:", error)
    }
  }

  const handleAddDependency = (sourceCardId: string) => {
    setNewDependencyData({
      sourceCardId,
      targetCardId: "",
    })
    setIsDependencyDialogOpen(true)
  }

  const handleSaveDependency = async () => {
    if (!user || !board || !newDependencyData.sourceCardId || !newDependencyData.targetCardId) return

    // Check if dependency already exists
    const existingDependency = dependencies.find(
      (dep) =>
        dep.sourceCardId === newDependencyData.sourceCardId && dep.targetCardId === newDependencyData.targetCardId,
    )

    if (existingDependency) {
      setIsDependencyDialogOpen(false)
      return
    }

    try {
      const newDependency = await db.createDependency({
        sourceCardId: newDependencyData.sourceCardId,
        targetCardId: newDependencyData.targetCardId,
        boardId: board.id,
        createdBy: user.id,
      })

      setDependencies([...dependencies, newDependency])
      setIsDependencyDialogOpen(false)
      setNewDependencyData({
        sourceCardId: "",
        targetCardId: "",
      })
    } catch (error) {
      console.error("Failed to create dependency:", error)
    }
  }

  const handleDeleteDependency = async (dependencyId: string) => {
    try {
      const success = await db.deleteDependency(dependencyId)
      if (success) {
        setDependencies(dependencies.filter((dep) => dep.id !== dependencyId))
      }
    } catch (error) {
      console.error("Failed to delete dependency:", error)
    }
  }

  const handleUpdateCardLabel = async (cardId: string, label: string) => {
    try {
      const updatedCard = await db.updateCard(cardId, {
        labels: label ? [label] : [],
      })

      if (updatedCard) {
        setCards(cards.map((card) => (card.id === updatedCard.id ? updatedCard : card)))
      }
    } catch (error) {
      console.error("Failed to update card label:", error)
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  if (!board || !user) {
    router.push("/dashboard")
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex flex-col">
      <header className="bg-background border-b sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Layout className="h-5 w-5 text-primary" />
                {board.title}
              </h1>
              {board.description && <p className="text-sm text-muted-foreground">{board.description}</p>}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">{user.name}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-x-auto p-4" ref={boardRef}>
        <DndContext
          sensors={sensors}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="flex gap-4 min-h-[calc(100vh-8rem)]">
            <SortableContext items={columns.map((col) => col.id)}>
              {columns.map((column) => (
                <Column
                  key={column.id}
                  column={column}
                  cards={cards.filter((card) => card.columnId === column.id).sort((a, b) => a.order - b.order)}
                  onAddCard={() => handleAddCard(column.id)}
                  onEditCard={handleEditCard}
                  onDeleteCard={handleDeleteCard}
                  onAddDependency={handleAddDependency}
                  onUpdateCardLabel={handleUpdateCardLabel}
                />
              ))}
            </SortableContext>
          </div>

          {boardRef.current && (
            <DependencyVisualizer
              dependencies={dependencies}
              cards={cards}
              boardRef={boardRef}
              onDeleteDependency={handleDeleteDependency}
            />
          )}
        </DndContext>
      </main>

      {/* Card Dialog */}
      <Dialog open={isCardDialogOpen} onOpenChange={setIsCardDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCard ? "Edit Card" : "Add New Card"}</DialogTitle>
            <DialogDescription>{editingCard ? "Update the card details" : "Create a new task card"}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                placeholder="Enter card title"
                value={newCardData.title}
                onChange={(e) => setNewCardData({ ...newCardData, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                placeholder="Enter card description"
                value={newCardData.description}
                onChange={(e) => setNewCardData({ ...newCardData, description: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCardDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveCard}>{editingCard ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dependency Dialog */}
      <Dialog open={isDependencyDialogOpen} onOpenChange={setIsDependencyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Dependency</DialogTitle>
            <DialogDescription>Select a card that depends on the current card</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="targetCard">This card blocks:</Label>
              <select
                id="targetCard"
                className="w-full p-2 border rounded-md"
                value={newDependencyData.targetCardId}
                onChange={(e) => setNewDependencyData({ ...newDependencyData, targetCardId: e.target.value })}
              >
                <option value="">Select a card</option>
                {cards
                  .filter((card) => card.id !== newDependencyData.sourceCardId)
                  .map((card) => (
                    <option key={card.id} value={card.id}>
                      {card.title}
                    </option>
                  ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDependencyDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveDependency} disabled={!newDependencyData.targetCardId}>
              Add Dependency
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
