"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { getCurrentUser } from "@/lib/auth"
import { db } from "@/lib/db"
import type { Board, User } from "@/lib/db/schema"
import { formatDate } from "@/lib/utils"
import { Layout, PlusCircle } from "lucide-react"

// Array of gradient classes for board cards
const BOARD_GRADIENTS = [
  "from-taskforge-purple/20 to-taskforge-blue/10",
  "from-taskforge-blue/20 to-taskforge-cyan/10",
  "from-taskforge-green/20 to-taskforge-teal/10",
  "from-taskforge-yellow/20 to-taskforge-orange/10",
  "from-taskforge-red/20 to-taskforge-pink/10",
  "from-taskforge-indigo/20 to-taskforge-purple/10",
]

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [boards, setBoards] = useState<Board[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newBoardTitle, setNewBoardTitle] = useState("")
  const [newBoardDescription, setNewBoardDescription] = useState("")

  useEffect(() => {
    async function loadData() {
      try {
        const currentUser = await getCurrentUser()
        setUser(currentUser)

        if (currentUser) {
          const userBoards = await db.getBoardsByUser(currentUser.id)
          setBoards(userBoards)
        }
      } catch (error) {
        console.error("Failed to load data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  const handleCreateBoard = async () => {
    if (!user || !newBoardTitle.trim()) return

    try {
      const newBoard = await db.createBoard({
        title: newBoardTitle.trim(),
        description: newBoardDescription.trim() || undefined,
        createdBy: user.id,
      })

      // Create default columns
      await db.createColumn({ boardId: newBoard.id, title: "To Do", order: 0 })
      await db.createColumn({ boardId: newBoard.id, title: "In Progress", order: 1 })
      await db.createColumn({ boardId: newBoard.id, title: "Done", order: 2 })

      setBoards([...boards, newBoard])
      setNewBoardTitle("")
      setNewBoardDescription("")
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Failed to create board:", error)
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  if (!user) {
    router.push("/login")
    return null
  }

  return (
    <div className="min-h-screen dashboard-bg">
      <header className="bg-background border-b shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary flex items-center gap-2">
            <Layout className="h-6 w-6" />
            TaskForge
          </h1>
          <div className="flex items-center gap-4">
            <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">{user.name}</span>
            <Button variant="outline" onClick={() => router.push("/login")}>
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-taskforge-purple to-taskforge-blue bg-clip-text text-transparent">
            My Boards
          </h2>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-taskforge-purple to-taskforge-blue hover:from-taskforge-purple/90 hover:to-taskforge-blue/90">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Board
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Board</DialogTitle>
                <DialogDescription>Create a new board to organize your tasks.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Board Title</Label>
                  <Input
                    id="title"
                    placeholder="Enter board title"
                    value={newBoardTitle}
                    onChange={(e) => setNewBoardTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Enter board description"
                    value={newBoardDescription}
                    onChange={(e) => setNewBoardDescription(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateBoard}>Create Board</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {boards.length === 0 ? (
          <div className="text-center py-12 bg-white/50 backdrop-blur-sm rounded-xl shadow-lg border border-white/20">
            <h3 className="text-xl font-medium mb-2">No boards yet</h3>
            <p className="text-muted-foreground mb-4">Create your first board to get started</p>
            <Button
              onClick={() => setIsDialogOpen(true)}
              className="bg-gradient-to-r from-taskforge-purple to-taskforge-blue hover:from-taskforge-purple/90 hover:to-taskforge-blue/90"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Create Board
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {boards.map((board, index) => (
              <Link href={`/board/${board.id}`} key={board.id}>
                <Card
                  className={`h-full hover:shadow-lg transition-all cursor-pointer bg-gradient-to-br ${BOARD_GRADIENTS[index % BOARD_GRADIENTS.length]} border-white/20 hover:scale-[1.02]`}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Layout className="h-5 w-5 text-taskforge-purple" />
                      {board.title}
                    </CardTitle>
                    {board.description && <CardDescription>{board.description}</CardDescription>}
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">Created on {formatDate(board.createdAt)}</p>
                  </CardContent>
                  <CardFooter>
                    <Button variant="secondary" className="w-full bg-white/50 hover:bg-white/70">
                      Open Board
                    </Button>
                  </CardFooter>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
