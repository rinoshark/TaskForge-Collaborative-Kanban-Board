"use client"

import type React from "react"

import { useEffect, useState } from "react"
import type { Card, Dependency } from "@/lib/db/schema"

interface DependencyVisualizerProps {
  dependencies: Dependency[]
  cards: Card[]
  boardRef: React.RefObject<HTMLDivElement>
  onDeleteDependency: (id: string) => void
}

interface ArrowPosition {
  id: string
  dependencyId: string
  sourceX: number
  sourceY: number
  targetX: number
  targetY: number
}

export default function DependencyVisualizer({
  dependencies,
  cards,
  boardRef,
  onDeleteDependency,
}: DependencyVisualizerProps) {
  const [arrows, setArrows] = useState<ArrowPosition[]>([])
  const [selectedArrow, setSelectedArrow] = useState<string | null>(null)

  useEffect(() => {
    function calculateArrowPositions() {
      if (!boardRef.current) return

      const newArrows: ArrowPosition[] = []

      dependencies.forEach((dependency) => {
        const sourceCard = document.querySelector(`[data-card-id="${dependency.sourceCardId}"]`)
        const targetCard = document.querySelector(`[data-card-id="${dependency.targetCardId}"]`)

        if (!sourceCard || !targetCard) return

        const sourceRect = sourceCard.getBoundingClientRect()
        const targetRect = targetCard.getBoundingClientRect()
        const boardRect = boardRef.current.getBoundingClientRect()

        // Calculate positions relative to the board
        const sourceX = sourceRect.left + sourceRect.width / 2 - boardRect.left + boardRef.current.scrollLeft
        const sourceY = sourceRect.top + sourceRect.height / 2 - boardRect.top + boardRef.current.scrollTop
        const targetX = targetRect.left + targetRect.width / 2 - boardRect.left + boardRef.current.scrollLeft
        const targetY = targetRect.top + targetRect.height / 2 - boardRect.top + boardRef.current.scrollTop

        newArrows.push({
          id: `${dependency.sourceCardId}-${dependency.targetCardId}`,
          dependencyId: dependency.id,
          sourceX,
          sourceY,
          targetX,
          targetY,
        })
      })

      setArrows(newArrows)
    }

    calculateArrowPositions()

    // Recalculate on scroll and resize
    const board = boardRef.current
    if (board) {
      board.addEventListener("scroll", calculateArrowPositions)
      window.addEventListener("resize", calculateArrowPositions)

      // Create a MutationObserver to watch for DOM changes
      const observer = new MutationObserver(calculateArrowPositions)
      observer.observe(board, { childList: true, subtree: true })

      return () => {
        board.removeEventListener("scroll", calculateArrowPositions)
        window.removeEventListener("resize", calculateArrowPositions)
        observer.disconnect()
      }
    }
  }, [dependencies, boardRef])

  // Calculate the SVG dimensions based on the arrows
  const svgWidth = boardRef.current?.scrollWidth || 2000
  const svgHeight = boardRef.current?.scrollHeight || 1000

  return (
    <div className="absolute top-0 left-0 pointer-events-none" style={{ width: svgWidth, height: svgHeight }}>
      <svg width={svgWidth} height={svgHeight} className="absolute top-0 left-0">
        {arrows.map((arrow) => {
          // Calculate the angle for the arrowhead
          const angle = Math.atan2(arrow.targetY - arrow.sourceY, arrow.targetX - arrow.sourceX)

          // Calculate the position for the arrowhead
          const arrowLength = 10
          const arrowX1 = arrow.targetX - arrowLength * Math.cos(angle - Math.PI / 6)
          const arrowY1 = arrow.targetY - arrowLength * Math.sin(angle - Math.PI / 6)
          const arrowX2 = arrow.targetX - arrowLength * Math.cos(angle + Math.PI / 6)
          const arrowY2 = arrow.targetY - arrowLength * Math.sin(angle + Math.PI / 6)

          // Calculate control points for the curve
          const dx = arrow.targetX - arrow.sourceX
          const dy = arrow.targetY - arrow.sourceY
          const controlX = arrow.sourceX + dx / 2
          const controlY = arrow.sourceY + dy / 2

          const isSelected = selectedArrow === arrow.id

          return (
            <g key={arrow.id}>
              {/* Invisible wider path for easier selection */}
              <path
                d={`M ${arrow.sourceX} ${arrow.sourceY} Q ${controlX} ${controlY} ${arrow.targetX} ${arrow.targetY}`}
                stroke="transparent"
                strokeWidth={20}
                fill="none"
                className="pointer-events-auto cursor-pointer"
                onClick={() => setSelectedArrow(isSelected ? null : arrow.id)}
              />

              {/* Visible path */}
              <path
                d={`M ${arrow.sourceX} ${arrow.sourceY} Q ${controlX} ${controlY} ${arrow.targetX} ${arrow.targetY}`}
                stroke={isSelected ? "var(--primary)" : "var(--muted-foreground)"}
                strokeWidth={2}
                strokeDasharray={isSelected ? "none" : "5,5"}
                fill="none"
                markerEnd="url(#arrowhead)"
              />

              {/* Arrowhead */}
              <polygon
                points={`${arrow.targetX},${arrow.targetY} ${arrowX1},${arrowY1} ${arrowX2},${arrowY2}`}
                fill={isSelected ? "var(--primary)" : "var(--muted-foreground)"}
              />

              {/* Delete button (only shown when selected) */}
              {isSelected && (
                <g
                  className="pointer-events-auto cursor-pointer"
                  onClick={() => {
                    onDeleteDependency(arrow.dependencyId)
                    setSelectedArrow(null)
                  }}
                >
                  <circle cx={controlX} cy={controlY} r={12} fill="var(--destructive)" />
                  <text
                    x={controlX}
                    y={controlY}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill="white"
                    fontSize={14}
                    fontWeight="bold"
                  >
                    ×
                  </text>
                </g>
              )}
            </g>
          )
        })}
      </svg>
    </div>
  )
}
