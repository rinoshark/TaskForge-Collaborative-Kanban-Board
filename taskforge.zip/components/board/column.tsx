"use client"

import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Card as CardComponent } from "@/components/ui/card"
import type { Column, Card as CardType } from "@/lib/db/schema"
import { PlusCircle } from "lucide-react"
import Card from "./card"

interface ColumnProps {
  column: Column
  cards: CardType[]
  onAddCard: (columnId: string) => void
  onEditCard: (card: CardType) => void
  onDeleteCard: (cardId: string) => void
  onAddDependency: (cardId: string) => void
  onUpdateCardLabel: (cardId: string, label: string) => void
}

// Map column titles to color themes
const getColumnTheme = (title: string) => {
  const lowerTitle = title.toLowerCase()
  if (lowerTitle.includes("to do") || lowerTitle.includes("todo") || lowerTitle.includes("backlog")) {
    return "blue"
  } else if (lowerTitle.includes("in progress") || lowerTitle.includes("doing")) {
    return "purple"
  } else if (lowerTitle.includes("done") || lowerTitle.includes("completed")) {
    return "green"
  }
  // Default theme based on column index
  return "blue"
}

export default function Column({
  column,
  cards,
  onAddCard,
  onEditCard,
  onDeleteCard,
  onAddDependency,
  onUpdateCardLabel,
}: ColumnProps) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
    id: column.id,
    data: {
      type: "column",
      column,
    },
  })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  const columnTheme = getColumnTheme(column.title)

  return (
    <div ref={setNodeRef} style={style} className="w-80 flex-shrink-0">
      <CardComponent className="h-full flex flex-col">
        <div
          className={`p-4 font-medium border-b rounded-t-lg column-header-${columnTheme}`}
          {...attributes}
          {...listeners}
        >
          <div className="flex justify-between items-center">
            <h3 className="font-semibold">{column.title}</h3>
            <span className="text-muted-foreground text-sm bg-background/80 px-2 py-0.5 rounded-full">
              {cards.length}
            </span>
          </div>
        </div>

        <div className="p-2 flex-1 overflow-y-auto max-h-[calc(100vh-12rem)]">
          {cards.map((card) => (
            <Card
              key={card.id}
              card={card}
              onEdit={() => onEditCard(card)}
              onDelete={() => onDeleteCard(card.id)}
              onAddDependency={() => onAddDependency(card.id)}
              onUpdateLabel={(label) => onUpdateCardLabel(card.id, label)}
            />
          ))}

          <button
            className="w-full p-2 mt-2 text-sm flex items-center justify-center gap-1 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted transition-colors border border-dashed border-muted-foreground/30 hover:border-muted-foreground/50"
            onClick={() => onAddCard(column.id)}
          >
            <PlusCircle className="h-4 w-4" />
            Add Card
          </button>
        </div>
      </CardComponent>
    </div>
  )
}
