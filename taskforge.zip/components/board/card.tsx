"use client"

import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Card as CardComponent, CardContent } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type { Card as CardType } from "@/lib/db/schema"
import { Clock, MoreHorizontal, Tag } from "lucide-react"

interface CardProps {
  card: CardType
  onEdit: () => void
  onDelete: () => void
  onAddDependency: () => void
  onUpdateLabel: (label: string) => void
}

const LABEL_COLORS = [
  { name: "Purple", value: "purple" },
  { name: "Blue", value: "blue" },
  { name: "Green", value: "green" },
  { name: "Yellow", value: "yellow" },
  { name: "Red", value: "red" },
  { name: "Pink", value: "pink" },
  { name: "Indigo", value: "indigo" },
  { name: "Cyan", value: "cyan" },
  { name: "Orange", value: "orange" },
  { name: "Teal", value: "teal" },
]

export default function Card({ card, onEdit, onDelete, onAddDependency, onUpdateLabel }: CardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: card.id,
    data: {
      type: "card",
      card,
    },
  })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const cardLabel = card.labels && card.labels.length > 0 ? card.labels[0] : null

  return (
    <CardComponent
      ref={setNodeRef}
      style={style}
      className="mb-2 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow border-l-4"
      {...attributes}
      {...listeners}
      data-card-id={card.id}
      style={{
        ...style,
        borderLeftColor: cardLabel ? `var(--taskforge-${cardLabel})` : undefined,
      }}
    >
      <CardContent className="p-3">
        <div className="flex justify-between items-start gap-2">
          <div className="flex-1">
            <h4 className="text-sm font-medium">{card.title}</h4>
            {cardLabel && (
              <div className={`inline-flex items-center px-2 py-0.5 mt-1 rounded-full text-xs label-${cardLabel}`}>
                {cardLabel.charAt(0).toUpperCase() + cardLabel.slice(1)}
              </div>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-muted">
              <MoreHorizontal className="h-4 w-4" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>Edit</DropdownMenuItem>
              <DropdownMenuItem onClick={onAddDependency}>Add Dependency</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuSub>
                <DropdownMenuSubTrigger>
                  <Tag className="h-4 w-4 mr-2" />
                  <span>Set Label</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent>
                  {LABEL_COLORS.map((color) => (
                    <DropdownMenuItem key={color.value} onClick={() => onUpdateLabel(color.value)}>
                      <div className={`h-3 w-3 rounded-full mr-2 bg-taskforge-${color.value}`} />
                      {color.name}
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => onUpdateLabel("")}>Remove Label</DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onDelete} className="text-red-500 focus:text-red-500">
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {card.description && <p className="text-xs text-muted-foreground mt-1">{card.description}</p>}

        {card.dueDate && (
          <div className="flex items-center mt-2 text-xs text-muted-foreground">
            <Clock className="h-3 w-3 mr-1" />
            <span>{new Date(card.dueDate).toLocaleDateString()}</span>
          </div>
        )}
      </CardContent>
    </CardComponent>
  )
}
