import { v4 as uuidv4 } from "uuid"
import type { Board, Card, Column, Dependency, User } from "./schema"

// Mock database for now - in a real app, this would connect to your actual database
class Database {
  private users: User[] = []
  private boards: Board[] = []
  private columns: Column[] = []
  private cards: Card[] = []
  private dependencies: Dependency[] = []

  // User methods
  async createUser(user: Omit<User, "id">): Promise<User> {
    const newUser = { ...user, id: uuidv4() }
    this.users.push(newUser)
    return newUser
  }

  async getUserById(id: string): Promise<User | null> {
    return this.users.find((user) => user.id === id) || null
  }

  async getUserByEmail(email: string): Promise<User | null> {
    return this.users.find((user) => user.email === email) || null
  }

  // Board methods
  async createBoard(board: Omit<Board, "id" | "createdAt" | "updatedAt">): Promise<Board> {
    const now = new Date()
    const newBoard = {
      ...board,
      id: uuidv4(),
      createdAt: now,
      updatedAt: now,
    }
    this.boards.push(newBoard)
    return newBoard
  }

  async getBoardById(id: string): Promise<Board | null> {
    return this.boards.find((board) => board.id === id) || null
  }

  async getBoardsByUser(userId: string): Promise<Board[]> {
    return this.boards.filter((board) => board.createdBy === userId)
  }

  async updateBoard(id: string, data: Partial<Board>): Promise<Board | null> {
    const index = this.boards.findIndex((board) => board.id === id)
    if (index === -1) return null

    this.boards[index] = {
      ...this.boards[index],
      ...data,
      updatedAt: new Date(),
    }

    return this.boards[index]
  }

  async deleteBoard(id: string): Promise<boolean> {
    const initialLength = this.boards.length
    this.boards = this.boards.filter((board) => board.id !== id)

    // Also delete related columns, cards, and dependencies
    this.columns = this.columns.filter((column) => column.boardId !== id)
    this.cards = this.cards.filter((card) => card.boardId !== id)
    this.dependencies = this.dependencies.filter((dep) => dep.boardId !== id)

    return this.boards.length !== initialLength
  }

  // Column methods
  async createColumn(column: Omit<Column, "id">): Promise<Column> {
    const newColumn = { ...column, id: uuidv4() }
    this.columns.push(newColumn)
    return newColumn
  }

  async getColumnsByBoard(boardId: string): Promise<Column[]> {
    return this.columns.filter((column) => column.boardId === boardId).sort((a, b) => a.order - b.order)
  }

  async updateColumn(id: string, data: Partial<Column>): Promise<Column | null> {
    const index = this.columns.findIndex((column) => column.id === id)
    if (index === -1) return null

    this.columns[index] = { ...this.columns[index], ...data }
    return this.columns[index]
  }

  async deleteColumn(id: string): Promise<boolean> {
    const initialLength = this.columns.length
    this.columns = this.columns.filter((column) => column.id !== id)

    // Also delete related cards and dependencies
    const affectedCards = this.cards.filter((card) => card.columnId === id).map((card) => card.id)
    this.cards = this.cards.filter((card) => card.columnId !== id)
    this.dependencies = this.dependencies.filter(
      (dep) => !affectedCards.includes(dep.sourceCardId) && !affectedCards.includes(dep.targetCardId),
    )

    return this.columns.length !== initialLength
  }

  // Card methods
  async createCard(card: Omit<Card, "id" | "createdAt" | "updatedAt">): Promise<Card> {
    const now = new Date()
    const newCard = {
      ...card,
      id: uuidv4(),
      createdAt: now,
      updatedAt: now,
    }
    this.cards.push(newCard)
    return newCard
  }

  async getCardById(id: string): Promise<Card | null> {
    return this.cards.find((card) => card.id === id) || null
  }

  async getCardsByColumn(columnId: string): Promise<Card[]> {
    return this.cards.filter((card) => card.columnId === columnId).sort((a, b) => a.order - b.order)
  }

  async getCardsByBoard(boardId: string): Promise<Card[]> {
    return this.cards.filter((card) => card.boardId === boardId)
  }

  async updateCard(id: string, data: Partial<Card>): Promise<Card | null> {
    const index = this.cards.findIndex((card) => card.id === id)
    if (index === -1) return null

    this.cards[index] = {
      ...this.cards[index],
      ...data,
      updatedAt: new Date(),
    }

    return this.cards[index]
  }

  async deleteCard(id: string): Promise<boolean> {
    const initialLength = this.cards.length
    this.cards = this.cards.filter((card) => card.id !== id)

    // Also delete related dependencies
    this.dependencies = this.dependencies.filter((dep) => dep.sourceCardId !== id && dep.targetCardId !== id)

    return this.cards.length !== initialLength
  }

  // Dependency methods
  async createDependency(dependency: Omit<Dependency, "id" | "createdAt">): Promise<Dependency> {
    const newDependency = {
      ...dependency,
      id: uuidv4(),
      createdAt: new Date(),
    }
    this.dependencies.push(newDependency)
    return newDependency
  }

  async getDependenciesByBoard(boardId: string): Promise<Dependency[]> {
    return this.dependencies.filter((dep) => dep.boardId === boardId)
  }

  async getDependenciesByCard(cardId: string): Promise<Dependency[]> {
    return this.dependencies.filter((dep) => dep.sourceCardId === cardId || dep.targetCardId === cardId)
  }

  async deleteDependency(id: string): Promise<boolean> {
    const initialLength = this.dependencies.length
    this.dependencies = this.dependencies.filter((dep) => dep.id !== id)
    return this.dependencies.length !== initialLength
  }

  // Initialize with sample data for development
  async seed(userId: string): Promise<void> {
    // Create a sample board
    const board = await this.createBoard({
      title: "Project Alpha",
      description: "Main development board for Project Alpha",
      createdBy: userId,
    })

    // Create columns
    const todoColumn = await this.createColumn({
      boardId: board.id,
      title: "To Do",
      order: 0,
    })

    const inProgressColumn = await this.createColumn({
      boardId: board.id,
      title: "In Progress",
      order: 1,
    })

    const doneColumn = await this.createColumn({
      boardId: board.id,
      title: "Done",
      order: 2,
    })

    // Create cards
    const card1 = await this.createCard({
      columnId: todoColumn.id,
      boardId: board.id,
      title: "Design database schema",
      description: "Create the initial database schema for the project",
      createdBy: userId,
      order: 0,
    })

    const card2 = await this.createCard({
      columnId: todoColumn.id,
      boardId: board.id,
      title: "Implement authentication",
      description: "Set up user authentication system",
      createdBy: userId,
      order: 1,
    })

    const card3 = await this.createCard({
      columnId: inProgressColumn.id,
      boardId: board.id,
      title: "Create UI mockups",
      description: "Design the user interface mockups for the main screens",
      createdBy: userId,
      order: 0,
    })

    // Create dependencies
    await this.createDependency({
      sourceCardId: card1.id,
      targetCardId: card2.id,
      boardId: board.id,
      createdBy: userId,
    })
  }
}

// Export a singleton instance
export const db = new Database()
