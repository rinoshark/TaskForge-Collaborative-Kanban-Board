export type User = {
  id: string
  name: string
  email: string
  image?: string
}

export type Board = {
  id: string
  title: string
  description?: string
  createdBy: string
  createdAt: Date
  updatedAt: Date
}

export type Column = {
  id: string
  boardId: string
  title: string
  order: number
}

export type Card = {
  id: string
  columnId: string
  boardId: string
  title: string
  description?: string
  assignedTo?: string
  createdBy: string
  createdAt: Date
  updatedAt: Date
  order: number
  dueDate?: Date
  labels?: string[]
}

export type Dependency = {
  id: string
  sourceCardId: string
  targetCardId: string
  boardId: string
  createdBy: string
  createdAt: Date
}
