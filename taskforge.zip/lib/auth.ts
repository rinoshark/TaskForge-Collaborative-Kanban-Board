import { db } from "./db"

// Mock authentication for now
export async function signIn(email: string, password: string) {
  // In a real app, you would verify the password
  let user = await db.getUserByEmail(email)

  if (!user) {
    // Auto-create user for demo purposes
    user = await db.createUser({
      name: email.split("@")[0],
      email,
    })

    // Seed data for new users
    await db.seed(user.id)
  }

  return user
}

export async function getCurrentUser() {
  // In a real app, this would check the session
  const demoUser = await db.getUserByEmail("demo@example.com")
  if (!demoUser) {
    return db.createUser({
      name: "Demo User",
      email: "demo@example.com",
    })
  }
  return demoUser
}
